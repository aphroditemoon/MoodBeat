"""
MoodBeat — Enhanced Flask API v2.0
===================================
Fitur baru:
  - POST /api/recommend        → rekomendasi lagu dengan randomisasi opsional
  - POST /api/ai_chat          → AI chatbot akurat via Claude API (Anthropic)
  - POST /api/journal/export   → export jurnal sebagai file RTF/DOCX
  - POST /api/classify         → klasifikasi mood dari audio features (KNN)
  - GET  /api/moods            → daftar mood + metadata
  - GET  /api/songs/<mood>     → semua lagu per mood

Run:
  pip install flask flask-cors pandas scikit-learn anthropic
  python api.py
"""

import os, json, random, math, io, datetime, urllib.request, urllib.error
from flask import Flask, request, jsonify, send_file
try:
    from flask_cors import CORS
    HAS_CORS = True
except ImportError:
    HAS_CORS = False

import pandas as pd

try:
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.preprocessing import StandardScaler
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False

app = Flask(__name__)
if HAS_CORS:
    CORS(app)
else:
    @app.after_request
    def add_cors(response):
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type,x-api-key"
        response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
        return response

BASE        = os.path.dirname(os.path.abspath(__file__))
SONGS_PATH  = os.path.join(BASE, "songs.csv")
MODEL_PATH  = os.path.join(BASE, "mood_model.pkl")

# ── Anthropic API key dari environment variable ────────────────────────────
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

# ─── MOOD METADATA ────────────────────────────────────────────────────────
MOOD_META = {
    "overwhelmed": {
        "color": "#3B6EFF", "emoji": "😮‍💨",
        "description": "Too much at once. Let the music carry you.",
        "journal_prompt": "What is taking up the most mental space right now? Write it down and let it go.",
        "activity": "Try box breathing: inhale 4 counts, hold 4, exhale 4, hold 4.",
        "vibe": "calm, grounding",
        "target": {"valence": 0.30, "energy": 0.30, "tempo": 70},
    },
    "lonely": {
        "color": "#A29BFE", "emoji": "🌧",
        "description": "You're not alone in feeling alone.",
        "journal_prompt": "Who is one person you could reach out to today? What would you want to say?",
        "activity": "Write a letter to your past self — no need to send it.",
        "vibe": "warm, intimate",
        "target": {"valence": 0.22, "energy": 0.28, "tempo": 72},
    },
    "anxious": {
        "color": "#5EE5FF", "emoji": "😰",
        "description": "Your nervous system needs a signal. Music is it.",
        "journal_prompt": "What is the worst that could actually happen? Write it out, then write the most likely outcome.",
        "activity": "Name 5 things you can see, 4 you can touch, 3 you can hear.",
        "vibe": "steady, focused",
        "target": {"valence": 0.32, "energy": 0.45, "tempo": 90},
    },
    "tired": {
        "color": "#8B93B8", "emoji": "😴",
        "description": "Rest is productive. Put this on and close your eyes.",
        "journal_prompt": "What drained you most today? What would 'enough' look like right now?",
        "activity": "Lie down for 10 minutes. No phone. Just breath and sound.",
        "vibe": "slow, restful",
        "target": {"valence": 0.35, "energy": 0.17, "tempo": 65},
    },
    "happy": {
        "color": "#FFD93D", "emoji": "✨",
        "description": "Ride this wave. You've earned it.",
        "journal_prompt": "What made you smile today? How can you bring more of that into tomorrow?",
        "activity": "Text someone a genuine compliment right now.",
        "vibe": "energetic, joyful",
        "target": {"valence": 0.84, "energy": 0.77, "tempo": 120},
    },
    "heartbroken": {
        "color": "#74B9FF", "emoji": "💔",
        "description": "Heartbreak is love with nowhere to go. We've got you.",
        "journal_prompt": "What do you miss? What are you still holding onto that you could gently release?",
        "activity": "Hold something warm — a mug of tea, a blanket. Just be with yourself.",
        "vibe": "tender, honest",
        "target": {"valence": 0.17, "energy": 0.25, "tempo": 72},
    },
    "focus": {
        "color": "#00CEC9", "emoji": "🎯",
        "description": "Block the noise. Enter the zone.",
        "journal_prompt": "What is the one thing that would make today feel complete if done?",
        "activity": "Set a 25-minute Pomodoro timer. One task. Full attention.",
        "vibe": "clear, instrumental",
        "target": {"valence": 0.45, "energy": 0.42, "tempo": 100},
    },
    "healing": {
        "color": "#A29BFE", "emoji": "🌱",
        "description": "You're getting there. One song at a time.",
        "journal_prompt": "Write three things you're proud of yourself for this week, however small.",
        "activity": "Step outside for 5 minutes. Notice what's growing around you.",
        "vibe": "soft, hopeful",
        "target": {"valence": 0.55, "energy": 0.27, "tempo": 77},
    },
}

# ─── LOAD & SCORE SONGS ───────────────────────────────────────────────────

def load_songs() -> pd.DataFrame:
    df = pd.read_csv(SONGS_PATH)
    df.columns = [c.strip() for c in df.columns]
    return df

def duration_label(seconds: float) -> str:
    s = int(seconds)
    return f"{s // 60}:{s % 60:02d}"

def score_song(row: pd.Series, mood: str) -> float:
    """Multi-factor scoring: distance to mood target + popularity proxy + danceability."""
    t = MOOD_META[mood]["target"]
    # Weighted Euclidean distance to mood target
    dv = (row["valence"]     - t["valence"]) * 2.5
    de = (row["energy"]      - t["energy"])  * 2.0
    dt = (row["tempo"]       - t["tempo"])   / 120.0
    dist = math.sqrt(dv**2 + de**2 + dt**2)
    # Bonus for high danceability on happy/focus, penalty for low acousticness on ambient moods
    dance_bonus = 0.0
    if mood in ("happy", "focus"):
        dance_bonus = -row.get("danceability", 0.5) * 0.3
    acoustic_bonus = 0.0
    if mood in ("overwhelmed", "tired", "healing"):
        acoustic_bonus = -(row.get("acousticness", 0.5)) * 0.2
    # Lower = better
    return dist + dance_bonus + acoustic_bonus

def get_recommendations(mood: str, n: int = 8, randomize: bool = False) -> list:
    df = load_songs()
    pool = df[df["primary_mood"].str.lower() == mood].copy()
    if pool.empty:
        return []

    pool["_score"] = pool.apply(lambda r: score_song(r, mood), axis=1)

    if randomize:
        # Weighted random sampling: better-scoring songs have higher probability
        pool["_weight"] = 1.0 / (pool["_score"] + 0.1)
        sample_n = min(n, len(pool))
        selected = pool.sample(n=sample_n, weights="_weight", replace=False)
    else:
        selected = pool.nsmallest(n, "_score")
        # Light shuffle so it doesn't always feel identical
        selected = selected.sample(frac=1).reset_index(drop=True)

    result = []
    for _, row in selected.iterrows():
        result.append({
            "id":         int(row["song_id"]),
            "title":      row["title"],
            "artist":     row["artist"],
            "genre":      row["genre"],
            "duration":   duration_label(row["duration_sec"]),
            "valence":    round(float(row["valence"]),  2),
            "energy":     round(float(row["energy"]),   2),
            "tempo":      round(float(row["tempo"]),    1),
            "cover":      str(row.get("cover_url", "")),
            "spotify_url": str(row.get("spotify_url", "")),
        })
    return result

# ─── KNN MOOD CLASSIFIER ─────────────────────────────────────────────────

_knn_model   = None
_knn_scaler  = None

_knn_features = ["valence","energy","tempo","danceability","acousticness","loudness","instrumentalness","speechiness"]

def build_knn():
    global _knn_model, _knn_scaler, _knn_features
    if not HAS_SKLEARN:
        return
    # Try loading pre-trained pkl bundle first
    if os.path.exists(MODEL_PATH):
        try:
            import pickle
            with open(MODEL_PATH, "rb") as f:
                bundle = pickle.load(f)
            _knn_model   = bundle["model"]
            _knn_scaler  = bundle["scaler"]
            _knn_features = bundle.get("features", _knn_features)
            acc = bundle.get("accuracy", "?")
            print(f"  Loaded mood_model.pkl  (accuracy={acc}, K={bundle.get('best_k','?')}, samples={bundle.get('trained_on','?')})")
            return
        except Exception as e:
            print(f"  PKL load failed ({e}), re-training…")
    # Fallback: train on-the-fly
    df = load_songs()
    X = df[_knn_features].fillna(0.5).values
    y = df["primary_mood"].str.lower().values
    _knn_scaler = StandardScaler()
    Xs = _knn_scaler.fit_transform(X)
    _knn_model = KNeighborsClassifier(n_neighbors=3, weights="distance", metric="euclidean")
    _knn_model.fit(Xs, y)
    print("  KNN trained on-the-fly")

build_knn()

# ─── CLAUDE AI CHAT ───────────────────────────────────────────────────────

def call_claude(system: str, user_msg: str, max_tokens: int = 200) -> str:
    """Call Claude claude-sonnet-4-6 via Anthropic Messages API."""
    if not ANTHROPIC_API_KEY:
        return ""
    payload = json.dumps({
        "model": "claude-sonnet-4-6",
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": user_msg}],
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={
            "Content-Type":      "application/json",
            "x-api-key":         ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
            return data["content"][0]["text"]
    except Exception:
        return ""

# ─── LOCAL AI FALLBACK (bahasa Indonesia) ────────────────────────────────

LOCAL_RESPONSES = {
    "overwhelmed": [
        "Perasaan kewalahan itu nyata. Pilih satu hal paling penting sekarang, dan biarkan musik ini membantu kamu memperlambat nafas.",
        "Otakmu sedang membawa terlalu banyak beban. Tulis pikiran yang paling keras dulu, lalu ambil satu langkah kecil.",
        "Ketika semua terasa terlalu banyak, mulailah dengan yang paling kecil. Selesaikan satu hal, lalu yang berikutnya.",
    ],
    "lonely": [
        "Merasa sendirian bukan berarti kamu sulit dicintai. Coba kirim satu pesan singkat ke seseorang yang aman bagimu.",
        "Kesendirian sering datang saat kita paling butuh koneksi. Biarkan lagu ini menemanimu sebelum kamu memutuskan siapa yang bisa dihubungi.",
        "Kamu tidak harus merasa baik-baik saja. Tapi kamu tidak harus sendirian dengan perasaan ini juga.",
    ],
    "anxious": [
        "Tubuhmu butuh bukti bahwa kamu aman. Tarik nafas perlahan — 4 hitungan masuk, 4 hitungan keluar.",
        "Kecemasan suka melompat ke masa depan. Tarik balik ke satu tindakan konkret yang bisa diselesaikan hari ini.",
        "Tanganmu di mana sekarang? Perhatikan sensasi fisik itu. Itu tanda kamu ada di sini, sekarang, aman.",
    ],
    "tired": [
        "Kamu tidak perlu mendapatkan istirahat. Turunkan kecerahan, jedakan satu hal yang tidak mendesak.",
        "Lelah adalah informasi, bukan kegagalan. Pilih versi paling ringan dari tugas berikutmu.",
        "Biarkan musiknya melakukan kerja keras sementara kamu beristirahat. Kamu sudah cukup melakukan banyak hari ini.",
    ],
    "happy": [
        "Pertahankan perasaan baik ini. Simpan lagu ini, kirim ke seseorang, atau lakukan satu hal yang akan membuat dirimu berterima kasih.",
        "Ini momen yang bagus untuk memperhatikan apa yang memberimu energi. Detail itu bisa jadi ritual yang bisa diulang.",
        "Perasaan baik ini layak dirayakan. Bagikan dengan orang di sekitarmu hari ini.",
    ],
    "heartbroken": [
        "Patah hati datang dalam gelombang. Kamu tidak perlu menyelesaikan seluruh perasaan ini malam ini.",
        "Merindukan seseorang bisa terasa nyata bahkan ketika melanjutkan hidup adalah hal yang tepat. Jujurlah, lalu lembutlah.",
        "Luka ini nyata, dan butuh waktu untuk sembuh. Beri dirimu izin untuk merasakannya tanpa menghakimi.",
    ],
    "focus": [
        "Gerak terbaikmu adalah menghapus satu gangguan sebelum mulai. Satu tab, satu tugas, satu lagu.",
        "Gunakan lagu ini seperti gerbang fokus. Ketika mulai, mulailah versi terkecil dari pekerjaanmu.",
        "Fokus bukan soal motivasi — soal menyingkirkan hambatan. Apa satu hambatan yang bisa kamu hapus sekarang?",
    ],
    "healing": [
        "Penyembuhan biasanya terlihat tenang sebelum terlihat mengesankan. Perhatikan satu tanda kecil bahwa kamu lebih baik dari sebelumnya.",
        "Kamu boleh tumbuh dengan pelan. Teruslah memilih tindakan kecil yang membuat hari esok sedikit lebih ringan.",
        "Setiap hari kamu memilih untuk terus adalah bentuk keberanian. Kamu sudah lebih jauh dari yang kamu sadari.",
    ],
}

def local_ai_response(mood: str, question: str, track: dict = None) -> str:
    pool = LOCAL_RESPONSES.get(mood, LOCAL_RESPONSES["healing"])
    idx = abs(sum(ord(c) for c in question)) % len(pool)
    base = pool[idx]
    music_line = f' Lagu "{track["title"]}" bisa jadi ankermu saat ini.' if track else ""
    return base + music_line

# ─── JOURNAL EXPORT (RTF) ─────────────────────────────────────────────────

def build_rtf(mood: str, text: str, song_info: str, date_str: str, time_str: str) -> bytes:
    mood_emoji = MOOD_META.get(mood, {}).get("emoji", "🎵")
    escaped = (text
               .replace("\\", "\\\\")
               .replace("{",  "\\{")
               .replace("}",  "\\}"))
    lines = escaped.split("\n")
    para_lines = "\n".join(f"{{\\f1\\fs24 {line}}}\\par" for line in lines)

    rtf = (
        r"{\rtf1\ansi\deff0" + "\n"
        r"{\fonttbl{\f0\froman\fcharset0 Times New Roman;}{\f1\fswiss\fcharset0 Arial;}}" + "\n"
        r"{\colortbl;\red59\green110\blue255;\red107\green117\blue168;\red0\green0\blue0;}" + "\n"
        r"\paperw12240\paperh15840\margl1800\margr1800\margt1440\margb1440" + "\n"
        r"\pard\qc{\f1\fs36\b\cf1 MoodBeat Journal " + mood_emoji + r"}\par" + "\n"
        r"\pard\qc{\f1\fs20\cf2 " + date_str + r" \bullet " + time_str + r"}\par" + "\n"
        r"\par" + "\n"
        r"\pard{\f1\fs24\b Mood: " + mood.capitalize() + " " + mood_emoji + r"}\par" + "\n"
        r"{\f1\fs20\cf2 Song companion: " + song_info + r"}\par" + "\n"
        r"\par" + "\n"
        r"\pard\brdrb\brdrs\brdrw10\brdrsp20{\f1\fs22\b\cf1 Journal Entry}\par" + "\n"
        r"\par" + "\n"
        + para_lines + "\n"
        r"\par" + "\n"
        r"\pard\qc{\f1\fs16\i\cf2 Generated by MoodBeat \emdash  Understand your mood through music.}\par" + "\n"
        r"}"
    )
    return rtf.encode("latin-1", errors="replace")

# ═══════════════════════════════════════════════════════════════════════════
# ROUTES
# ═══════════════════════════════════════════════════════════════════════════

@app.route("/api/moods", methods=["GET"])
def get_moods():
    safe_meta = {k: {kk: vv for kk, vv in v.items() if kk != "target"} for k, v in MOOD_META.items()}
    return jsonify({"moods": list(MOOD_META.keys()), "meta": safe_meta})


@app.route("/api/songs/<mood>", methods=["GET"])
def get_songs_for_mood(mood):
    mood = mood.lower().strip()
    if mood not in MOOD_META:
        return jsonify({"error": f"Unknown mood. Valid: {list(MOOD_META.keys())}"}), 400
    df = load_songs()
    songs = df[df["primary_mood"].str.lower() == mood]
    result = []
    for _, row in songs.iterrows():
        result.append({
            "id":         int(row["song_id"]),
            "title":      row["title"],
            "artist":     row["artist"],
            "genre":      row["genre"],
            "duration":   duration_label(row["duration_sec"]),
            "valence":    round(float(row["valence"]), 2),
            "energy":     round(float(row["energy"]),  2),
            "cover":      str(row.get("cover_url", "")),
            "spotify_url": str(row.get("spotify_url", "")),
        })
    return jsonify({"mood": mood, "count": len(result), "songs": result})


@app.route("/api/recommend", methods=["POST", "OPTIONS"])
def recommend():
    if request.method == "OPTIONS":
        return "", 204
    data   = request.get_json(silent=True) or {}
    mood   = str(data.get("mood", "")).lower().strip()
    n      = min(max(int(data.get("n", 8)), 1), 20)
    randomize = bool(data.get("randomize", False))   # ← NEW: randomize flag

    if mood not in MOOD_META:
        return jsonify({"error": f"Unknown mood. Choose from: {list(MOOD_META.keys())}"}), 400

    songs = get_recommendations(mood, n, randomize=randomize)
    meta  = {k: v for k, v in MOOD_META[mood].items() if k != "target"}
    return jsonify({"mood": mood, **meta, "songs": songs, "randomized": randomize})


@app.route("/api/classify", methods=["POST", "OPTIONS"])
def classify():
    """Classify mood from audio features using KNN (or fallback distance)."""
    if request.method == "OPTIONS":
        return "", 204
    data     = request.get_json(silent=True) or {}
    features = data.get("features", {})
    try:
        valence       = float(features.get("valence",       0.5))
        energy        = float(features.get("energy",        0.5))
        tempo         = float(features.get("tempo",         90))
        danceability  = float(features.get("danceability",  0.5))
        acousticness  = float(features.get("acousticness",  0.5))
        speechiness   = float(features.get("speechiness",   0.05))
    except (TypeError, ValueError) as e:
        return jsonify({"error": str(e)}), 400

    if HAS_SKLEARN and _knn_model is not None:
        feat_vals = {"valence": valence, "energy": energy, "tempo": tempo,
                     "danceability": danceability, "acousticness": acousticness,
                     "loudness": float(features.get("loudness", -12)),
                     "instrumentalness": float(features.get("instrumentalness", 0.05)),
                     "speechiness": speechiness}
        X = [[feat_vals.get(f, 0.5) for f in _knn_features]]
        Xs = _knn_scaler.transform(X)
        probs = dict(zip(_knn_model.classes_, _knn_model.predict_proba(Xs)[0]))
        best  = max(probs, key=probs.get)
        confidence = round(probs[best], 3)
    else:
        # Weighted distance fallback
        best = min(
            MOOD_META,
            key=lambda m: (
                ((valence - MOOD_META[m]["target"]["valence"]) * 2.5) ** 2
                + ((energy - MOOD_META[m]["target"]["energy"]) * 2.0) ** 2
                + ((tempo  - MOOD_META[m]["target"]["tempo"])  / 120) ** 2
            ),
        )
        confidence = 0.75

    return jsonify({"mood": best, "confidence": confidence})


@app.route("/api/ai_chat", methods=["POST", "OPTIONS"])
def ai_chat():
    """
    Accurate mood-aware AI chatbot using Claude API with full context.
    Falls back to curated local responses if API key is not set.
    
    Request body:
      { "mood": "happy", "question": "...", "track": {"title": "...", "artist": "...", "genre": "...", "valence": 0.8, "energy": 0.7} }
    """
    if request.method == "OPTIONS":
        return "", 204
    data     = request.get_json(silent=True) or {}
    mood     = str(data.get("mood", "healing")).lower().strip()
    question = str(data.get("question", "")).strip()
    track    = data.get("track")        # optional: current song context
    lang     = str(data.get("lang", "id"))  # "id" = Indonesian, "en" = English

    if not question:
        return jsonify({"error": "question is required"}), 400
    if mood not in MOOD_META:
        mood = "healing"

    # Build rich system prompt
    meta = MOOD_META[mood]
    track_ctx = ""
    if track:
        track_ctx = (
            f'\nThe user is currently listening to "{track.get("title","")}" '
            f'by {track.get("artist","")} '
            f'({track.get("genre","")}, valence: {track.get("valence",0.5)}, '
            f'energy: {track.get("energy",0.5)}).'
        )

    system_prompt = f"""You are MoodBeat AI, a compassionate and emotionally intelligent music-therapy companion.

Context:
- User's current mood: "{mood}" ({meta['emoji']}) — {meta['description']}
- Mood vibe: {meta['vibe']}{track_ctx}
- Journal prompt for this mood: "{meta['journal_prompt']}"
- Suggested activity: "{meta['activity']}"

Your response rules:
1. Directly and specifically address what the user wrote — never give a generic answer.
2. Weave in the current song or mood context naturally when relevant.
3. Be concise (2-3 sentences max), warm, and conversational — like a caring friend who understands music and emotions deeply.
4. Offer one gentle, concrete, actionable suggestion tailored to what the user shared.
5. Do NOT use bullet points, headers, or lists. Plain flowing text only.
6. Respond in {"Bahasa Indonesia" if lang == "id" else "English"}.
7. Never start with "I" or "As an AI". Start with empathy or insight about what the user shared."""

    ai_text = call_claude(system_prompt, question, max_tokens=200)

    if not ai_text:
        ai_text = local_ai_response(mood, question, track)

    return jsonify({"response": ai_text, "mood": mood, "source": "claude" if ai_text and ANTHROPIC_API_KEY else "local"})


@app.route("/api/journal/export", methods=["POST", "OPTIONS"])
def journal_export():
    """
    Export journal entry as RTF file (opens in Word, Google Docs, Pages).
    
    Request body:
      { "mood": "happy", "text": "...", "track": {"title": "...", "artist": "..."} }
    """
    if request.method == "OPTIONS":
        return "", 204
    data  = request.get_json(silent=True) or {}
    mood  = str(data.get("mood", "healing")).lower().strip()
    text  = str(data.get("text", "")).strip()
    track = data.get("track")

    if not text:
        return jsonify({"error": "text is required"}), 400
    if mood not in MOOD_META:
        mood = "healing"

    now       = datetime.datetime.now()
    date_str  = now.strftime("%A, %d %B %Y")
    time_str  = now.strftime("%H:%M")
    song_info = f'{track["title"]} — {track["artist"]}' if track else "(no song selected)"

    rtf_bytes = build_rtf(mood, text, song_info, date_str, time_str)
    fname     = f"MoodBeat_Journal_{mood}_{now.strftime('%Y-%m-%d')}.rtf"

    return send_file(
        io.BytesIO(rtf_bytes),
        mimetype="application/rtf",
        as_attachment=True,
        download_name=fname,
    )


@app.route("/", methods=["GET"])
def index():
    html_path = os.path.join(BASE, "index.html")
    if os.path.exists(html_path):
        with open(html_path, "r", encoding="utf-8") as f:
            return f.read(), 200, {"Content-Type": "text/html; charset=utf-8"}
    return jsonify({"status": "MoodBeat API running", "version": "2.0"}), 200


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status":    "ok",
        "knn_ready": HAS_SKLEARN and _knn_model is not None,
        "ai_ready":  bool(ANTHROPIC_API_KEY),
        "songs":     len(load_songs()),
        "moods":     list(MOOD_META.keys()),
    })


if __name__ == "__main__":
    print("=" * 55)
    print("  MoodBeat API v2.0  →  http://localhost:5000")
    print("=" * 55)
    print(f"  Songs loaded : {len(load_songs())}")
    print(f"  KNN model    : {'✓' if HAS_SKLEARN and _knn_model is not None else '✗ (scikit-learn missing)'}")
    print(f"  Claude AI    : {'✓' if ANTHROPIC_API_KEY else '✗ (set ANTHROPIC_API_KEY env var)'}")
    print("=" * 55)
    app.run(debug=True, port=5000)
