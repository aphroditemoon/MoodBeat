# MoodBeat v2.0 — Enhanced Edition

A Gen Z-styled web app connecting music, emotional awareness, self-care, and real-world Spotify-searchable tracks. Enhanced with AI chatbot, album cover art, journal export, animated UI, and intelligent randomization.

## Files

| File | Description |
|------|-------------|
| `index.html` | Full single-file website. Open directly in any browser. |
| `songs.csv` | Real-world song dataset (64 songs × 8 moods) with `cover_url` column added. |
| `api.py` | Flask backend API v2.0 with AI chat, journal export, KNN classify, randomize. |
| `mood_model.pkl` | Pre-trained KNN mood classifier (K=3, 8 features, ~55% cross-val accuracy). |

## New in v2.0

### index.html
- **Album cover art** — clicking a mood card replaces the emoji icon with the album cover of the first recommended song (smooth `albumReveal` animation)
- **AI chatbot accuracy** — uses Claude API (`claude-sonnet-4-6`) with full mood + song context in system prompt; falls back to curated Indonesian local responses
- **Randomized playlists** — clicking "Change Mood" re-selects the same mood with weighted-random song shuffle for variety
- **Download Journal** — after saving a note, a "⬇ Download Journal (.docx)" button appears; exports as RTF (opens in Word/Google Docs/Pages)
- **Particle system** — 80 animated particles that react to mouse movement and shift color with mood selection
- **Music note spawn** — ♪♫ notes float up on mood card click
- **Ripple burst** — expanding wave effect on click
- **Scroll reveal** — feature cards animate in on scroll (IntersectionObserver)
- **Mood card pulse** — active card glows rhythmically
- **Playlist item slide** — items slide right on hover

### api.py (v2.0)
- `POST /api/recommend` — now accepts `"randomize": true` for weighted-random shuffle
- `POST /api/ai_chat` — NEW: proxies to Claude API with rich system prompt including mood meta, song context, journal prompt, activity tip; falls back to curated Indonesian responses
- `POST /api/journal/export` — NEW: generates and streams RTF file for download
- `POST /api/classify` — upgraded: loads pre-trained KNN from `mood_model.pkl`, full 8-feature input, returns probability distribution
- `GET  /api/songs/<mood>` — NEW: list all songs for a specific mood
- `GET  /api/moods` — enhanced with emoji field per mood
- `GET  /health` — reports KNN readiness, AI key status, song count

### songs.csv
- Added `cover_url` column with Spotify CDN image URLs for every track

### mood_model.pkl
- Pre-trained `KNeighborsClassifier` (K=3, `weights="distance"`, `metric="euclidean"`)
- 8 features: `valence, energy, tempo, danceability, acousticness, loudness, instrumentalness, speechiness`
- Trained on all 64 songs; loaded automatically by `api.py` on startup

## Quick Start

### Browser only (no server needed)
```bash
open index.html
```

### With backend
```bash
pip install flask flask-cors pandas scikit-learn
export ANTHROPIC_API_KEY=sk-ant-...   # optional — enables real AI chat
python api.py
```

API runs at `http://localhost:5000`.

### Example API calls
```bash
# Get recommendations (randomized)
curl -X POST http://localhost:5000/api/recommend \
  -H "Content-Type: application/json" \
  -d '{"mood": "happy", "n": 8, "randomize": true}'

# AI chat
curl -X POST http://localhost:5000/api/ai_chat \
  -H "Content-Type: application/json" \
  -d '{"mood": "anxious", "question": "Kenapa saya susah tidur?", "lang": "id", "track": {"title": "Breathe Me", "artist": "Sia"}}'

# Classify mood from audio features
curl -X POST http://localhost:5000/api/classify \
  -H "Content-Type: application/json" \
  -d '{"features": {"valence": 0.85, "energy": 0.80, "tempo": 118, "danceability": 0.82, "acousticness": 0.15, "loudness": -6.0, "instrumentalness": 0.01, "speechiness": 0.05}}'

# Export journal as RTF
curl -X POST http://localhost:5000/api/journal/export \
  -H "Content-Type: application/json" \
  -d '{"mood": "healing", "text": "Hari ini lebih baik dari kemarin.", "track": {"title": "Rainbow", "artist": "Kacey Musgraves"}}' \
  --output journal.rtf
```
